from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.routes import router
app=FastAPI(title='PocketSmart AI')
app.mount('/static',StaticFiles(directory='static'),name='static')
app.state.templates=Jinja2Templates(directory='templates')
app.include_router(router)
