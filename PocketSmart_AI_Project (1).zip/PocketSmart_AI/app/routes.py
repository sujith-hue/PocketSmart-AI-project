from fastapi import APIRouter,Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from collections import defaultdict
router=APIRouter()
class Expense(BaseModel):
    category:str
    amount:float
    note:str=''
class Budget(BaseModel):
    income:float
    budget:float
    expenses:list[Expense]
def recommend(income,budget,expenses):
    total=sum(x.amount for x in expenses); out=[]
    if total>budget: out.append('Your expenses are above the planned budget. Reduce non-essential spending.')
    elif budget and total>=budget*.8: out.append('You have used more than 80% of your budget. Watch upcoming expenses.')
    else: out.append('Your spending is currently within the planned budget.')
    cats=defaultdict(float)
    for x in expenses: cats[x.category]+=x.amount
    if cats:
        top=max(cats,key=cats.get); out.append(f'{top} is your highest spending category. Review it for possible savings.')
    remain=budget-total
    if remain>0: out.append(f'Consider keeping about ₹{remain*.20:.2f} as savings.')
    if income: out.append(f'Your recorded expenses are {total/income*100:.1f}% of your income.')
    return out
@router.get('/',response_class=HTMLResponse)
async def home(request:Request): return request.app.state.templates.TemplateResponse('index.html',{'request':request})
@router.post('/api/analyze')
async def analyze(data:Budget):
    total=round(sum(x.amount for x in data.expenses),2); remain=round(data.budget-total,2)
    cats=defaultdict(float)
    for x in data.expenses: cats[x.category]+=x.amount
    return {'income':data.income,'budget':data.budget,'total_expense':total,'remaining':remain,'status':'Over Budget' if remain<0 else 'Within Budget','categories':dict(cats),'recommendations':recommend(data.income,data.budget,data.expenses)}
