# PocketSmart AI – Your Smart Budget & Recommendation Assistant

## Features
- Monthly income and budget input
- Expense tracking by category
- Total expense and remaining balance
- Category-wise spending summary
- Smart budget recommendations
- Over-budget warning
- FastAPI REST API
- Responsive dashboard UI

## Run
python -m venv pocketsmart-env
pocketsmart-env\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload

Open http://127.0.0.1:8000
API docs: http://127.0.0.1:8000/docs
